package com.example.restaurant_bayon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
