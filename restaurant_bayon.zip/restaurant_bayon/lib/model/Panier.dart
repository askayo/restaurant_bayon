import 'package:restaurant_bayon/model/Character.dart';

class Panier{
  final List<Plat> listPlats;
  final int nbArticles;
  final double prixTotal;

  Panier(this.listPlats, this.nbArticles, this.prixTotal);




}
